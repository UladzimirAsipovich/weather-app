"use strict";
(() => {
var exports = {};
exports.id = 591;
exports.ids = [591];
exports.modules = {

/***/ 6981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _location_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/_VAR.ts
var _VAR = __webpack_require__(3701);
;// CONCATENATED MODULE: ./components/Field/Field.tsx



const Field = (props)=>{
    const { 0: wrong , 1: setWrong  } = (0,external_react_.useState)(false);
    const { 0: checked , 1: setChecked  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        if (props.toClean !== undefined) {
            setChecked(false);
            setWrong(false);
            if (props.required && props.toRequired) {
                props.toRequired((prevState)=>{
                    return {
                        ...prevState,
                        [props.name]: false
                    };
                });
            }
        }
    }, [
        props.toClean
    ]);
    (0,external_react_.useEffect)(()=>{
        if (props.required && props.toRequired) {
            props.toRequired((prevState)=>{
                return {
                    ...prevState,
                    [props.name]: false
                };
            });
        }
    }, []);
    const checker = ({ currentTarget , currentTarget: { value  }  })=>{
        if (value.length === 0) {
            setChecked(false);
            setWrong(false);
            return;
        }
        let testResult = false;
        switch(props.type){
            case "text":
                {
                    testResult = (0,_VAR/* ONLY_ENG_LETTERS_REGEXP */.A)(2, 20).test(value);
                    break;
                }
        }
        if (testResult) {
            !checked && setChecked(true);
            wrong && setWrong(false);
            if (props.required && props.toRequired) {
                props.toRequired((prevState)=>{
                    return {
                        ...prevState,
                        [props.name]: true
                    };
                });
            }
        } else {
            checked && setChecked(false);
            !wrong && setWrong(true);
            if (props.required && props.toRequired) {
                props.toRequired((prevState)=>{
                    return {
                        ...prevState,
                        [props.name]: false
                    };
                });
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mb-4",
        children: [
            props.label ? /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: props.name,
                className: "",
                children: props.label
            }) : null,
            props.type !== "textarea" ? /*#__PURE__*/ jsx_runtime_.jsx("input", {
                className: `block px-4 py-2 border-2 rounded-lg ${wrong ? "border-red-400 outline-red-400" : null}`,
                type: props.type ?? "text",
                name: props.name,
                id: props.name,
                minLength: props.minLength ?? 2,
                maxLength: props.maxLength ?? 50,
                defaultValue: "",
                placeholder: props.placeholder ?? "",
                onChange: checker
            }) : /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                name: props.name,
                className: "",
                id: props.name,
                minLength: props.minLength ?? 2,
                maxLength: props.maxLength ?? 250,
                defaultValue: "",
                placeholder: props.placeholder ?? "",
                onChange: checker
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                className: "text-xs",
                children: wrong ? props.helpLabel?.wrong : props.helpLabel?.ok
            })
        ]
    });
};
/* harmony default export */ const Field_Field = (Field);

;// CONCATENATED MODULE: ./components/ChangeLocationForm/ChangeLocationForm.tsx



const ChangeLocationForm = (props)=>{
    const { 0: clean , 1: setClean  } = (0,external_react_.useState)(0); // form reset state trigger
    const { 0: valid , 1: setValid  } = (0,external_react_.useState)(false); // form validation status
    const { 0: requiredFields , 1: setRequiredFields  } = (0,external_react_.useState)({}); // store of required fields validate status
    const cleaner = ()=>{
        setClean(clean + 1);
        setValid(false);
    };
    const submitter = async (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const form = e.target;
        props.setLocation(form.location.value);
        setClean(clean + 1);
        setValid(false);
        form.reset();
    };
    (0,external_react_.useEffect)(()=>{
        let isValid = false;
        if (Object.values(requiredFields).length) {
            isValid = Object.values(requiredFields).every((el)=>el === true);
        }
        if (isValid) {
            setValid(true);
        } else {
            setValid(false);
        }
    }, [
        requiredFields
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "",
        onSubmit: submitter,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Field_Field, {
                name: "location",
                type: "text",
                label: "You can also view weather forecast for other cities:",
                placeholder: "Enter city name",
                helpLabel: {
                    ok: "",
                    wrong: "This field supporting latin characters only!"
                },
                toClean: clean,
                toRequired: setRequiredFields,
                required: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "submit",
                disabled: !valid,
                className: "px-4 py-2 border-2 rounded-lg text-white transition-colors bg-blue-400 hover:bg-blue-600 disabled:bg-slate-300",
                children: "Change Location"
            })
        ]
    });
};
/* harmony default export */ const ChangeLocationForm_ChangeLocationForm = (ChangeLocationForm);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/WeatherWidget/HourTile/HourTile.tsx


const HourTile = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "text-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                    className: "text-xs",
                    children: new Intl.DateTimeFormat("en-US", {
                        weekday: "short",
                        hour: "2-digit",
                        minute: "2-digit",
                        hour12: false
                    }).format(new Date(props.Day.dt_txt))
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-24 mx-auto",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: `http://openweathermap.org/img/wn/${props.Day.weather[0].icon}@2x.png`,
                    layout: "responsive",
                    width: 50,
                    height: 50,
                    alt: props.Day.weather[0].description
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("footer", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                    children: [
                        props.Day.main.temp,
                        "\xbaC"
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const HourTile_HourTile = (HourTile);

// EXTERNAL MODULE: ./components/WeatherWidget/OneDayTile/OneDayTile.tsx
var OneDayTile = __webpack_require__(8006);
// EXTERNAL MODULE: ./components/Modal/Modal.tsx
var Modal = __webpack_require__(9842);
// EXTERNAL MODULE: ./components/MetaHead/MetaHead.tsx
var MetaHead = __webpack_require__(3875);
;// CONCATENATED MODULE: ./pages/in/[location].tsx










const HourlyWeatherByLocation = (props)=>{
    const router = (0,router_namespaceObject.useRouter)();
    const { location  } = router.query;
    const { 0: serverStatus  } = (0,external_react_.useState)(props.Weather.message === 0);
    const { 0: cityIsNotFound , 1: SetCityIsNotFound  } = (0,external_react_.useState)(false);
    const { 0: CurrentLocation , 1: SetCurrentLocation  } = (0,external_react_.useState)(()=>{
        return location || props.currentLocation;
    });
    const { 0: DefaultLocation , 1: setDefaultLocation  } = (0,external_react_.useState)(()=>{
        if (false) {}
        return _VAR/* AvailableCities.0 */.i[0];
    });
    const { 0: WeatherData , 1: SetWeatherData  } = (0,external_react_.useState)(()=>{
        return null;
    });
    const { 0: isLoad , 1: SetIsLoad  } = (0,external_react_.useState)(false);
    const { 0: isFetching , 1: SetIsFetching  } = (0,external_react_.useState)(false);
    const { ShowModal  } = (0,Modal/* default */.Z)();
    const getAndCacheWeatherFor = (0,external_react_.useCallback)(async (city)=>{
        if (isFetching) return;
        SetIsFetching(true);
        const normalizeName = city.match("\\w+")?.toString();
        if (!normalizeName) {
            setDefaultLocation(_VAR/* AvailableCities.0 */.i[0]);
            localStorage.removeItem("DefaultLocation");
            SetIsFetching(false);
        }
        await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${normalizeName}&cnt=25&units=metric&appid=48f58ae9f7eda0872224b5872c167cb0`).then((res)=>res.json()).then((currentWeatherForCity)=>{
            if (currentWeatherForCity.message === 0) {
                localStorage.setItem("DefaultLocation", `${currentWeatherForCity.city.name}-${currentWeatherForCity.city.country}`);
                localStorage.setItem("cachedLastWeatherDataUpdated", new Date().getTime().toString());
                localStorage.setItem(`${currentWeatherForCity.city.name}-${currentWeatherForCity.city.country}`, JSON.stringify(currentWeatherForCity));
                setDefaultLocation(`${currentWeatherForCity.city.name}-${currentWeatherForCity.city.country}`);
                SetCurrentLocation(currentWeatherForCity.city.name);
                SetWeatherData(currentWeatherForCity);
                SetIsFetching(false);
                SetCityIsNotFound(false);
                SetIsLoad(true);
                return;
            }
            localStorage.removeItem("DefaultLocation");
            SetCityIsNotFound(true);
            SetIsFetching(false);
        });
    }, [
        isFetching
    ]);
    (0,external_react_.useEffect)(()=>{
        if (!localStorage.getItem(DefaultLocation) || cityIsNotFound || serverStatus === false) {
            ShowModal({
                type: "error",
                title: "Hi! Yor city is not found you must to change your current location.",
                AvailableCities: _VAR/* AvailableCities */.i,
                onOk: async (cityName)=>{
                    const selectedCity = cityName;
                    const parseCityName = cityName.match(/\w+/g);
                    if (localStorage.getItem(selectedCity)) {
                        setDefaultLocation(selectedCity);
                        const currentWeatherForCity = JSON.parse(localStorage.getItem(DefaultLocation));
                        SetWeatherData(currentWeatherForCity);
                        localStorage.setItem("DefaultLocation", `${currentWeatherForCity.city.name}-${currentWeatherForCity.city.country}`);
                        router.push(`/in/${parseCityName[0]}`);
                        return;
                    }
                    await getAndCacheWeatherFor(selectedCity);
                },
                onCancel: async ()=>{
                    await getAndCacheWeatherFor(_VAR/* AvailableCities.0 */.i[0]);
                }
            });
            return;
        } else {
            if (localStorage.getItem(DefaultLocation)) {
                try {
                    const storageWeather = JSON.parse(localStorage.getItem(DefaultLocation));
                    const lastUpdatedCache = Number(localStorage.getItem("cachedLastWeatherDataUpdated"));
                    const three_hours = 10800000;
                    const lastUpdatedForCurrentCityCache = new Date(storageWeather.list[0].dt_txt).getTime();
                    if (lastUpdatedCache > lastUpdatedForCurrentCityCache + three_hours) {
                        getAndCacheWeatherFor(DefaultLocation);
                        return;
                    }
                    SetWeatherData(storageWeather);
                    SetCurrentLocation(storageWeather.city.name);
                    SetIsLoad(true);
                    return;
                } catch (error) {
                    getAndCacheWeatherFor(DefaultLocation);
                }
            } else {
                getAndCacheWeatherFor(DefaultLocation);
                return;
            }
        }
    }, [
        DefaultLocation,
        cityIsNotFound,
        getAndCacheWeatherFor,
        serverStatus
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MetaHead/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container p-4 mx-auto max-w-6xl",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                        className: "mb-16",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: "Go to Home"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                className: "text-xs text-gray-400",
                                children: [
                                    "Thank you for using our service! ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-gray-400 font-serif font-light select-none",
                                        children: "JustWeather just for you!"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                className: "text-2xl font-light",
                                children: [
                                    "You see daily and hourly forecast weather for ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                        children: WeatherData?.city.name
                                    }),
                                    " city."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mx-auto",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "rounded-xl p-6 bg-blue-50 shadow-lg mb-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-serif font-light mb-6 inline-block w-full text-center text-xl",
                                        children: "Daily weather forecast"
                                    }),
                                    WeatherData ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "md:columns-3",
                                        children: [
                                            WeatherData.list[8],
                                            WeatherData.list[16],
                                            WeatherData.list[24]
                                        ].map((data, ind)=>/*#__PURE__*/ jsx_runtime_.jsx(OneDayTile/* default */.Z, {
                                                Day: data
                                            }, ind))
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Weather is loading..."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mb-8 rounded-xl p-6 bg-blue-50 shadow-lg",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "font-serif font-light mb-6 inline-block w-full text-center text-xl",
                                        children: "Hourly weather forecast"
                                    }),
                                    WeatherData ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "md:columns-8",
                                        children: WeatherData.list.slice(0, 8).map((data, ind)=>/*#__PURE__*/ jsx_runtime_.jsx(HourTile_HourTile, {
                                                Day: data
                                            }, ind))
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Weather is loading..."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ChangeLocationForm_ChangeLocationForm, {
                        setLocation: async (location)=>{
                            let normalize = location.toLowerCase();
                            normalize = normalize[0].toUpperCase() + normalize.slice(1);
                            await getAndCacheWeatherFor(normalize);
                            if (cityIsNotFound) {
                                return;
                            }
                            SetCurrentLocation(normalize);
                            router.push(`/in/${normalize}`);
                        },
                        setWeatherData: SetWeatherData
                    })
                ]
            })
        ]
    });
};
const getServerSideProps = async ({ req , res  })=>{
    res.setHeader("Cache-Control", "public, s-maxage=10, stale-while-revalidate=59");
    // /_next/data/development/in/Minsk.json?location=Minsk
    // /in /Minsk
    const searchingCity = req?.url?.match(/(\/in\/\w+)/g)?.join("").slice(4);
    const Weather = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${searchingCity}&cnt=25&units=metric&appid=48f58ae9f7eda0872224b5872c167cb0`).then((res)=>res.json()).then((data)=>{
        return data;
    }).catch((e)=>{
        console.log("Error", e);
    });
    return {
        props: {
            currentLocation: searchingCity,
            Weather
        }
    };
};
/* harmony default export */ const _location_ = (HourlyWeatherByLocation);


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,61,842,773], () => (__webpack_exec__(6981)));
module.exports = __webpack_exports__;

})();