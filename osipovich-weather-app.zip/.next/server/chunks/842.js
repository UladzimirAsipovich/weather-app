"use strict";
exports.id = 842;
exports.ids = [842];
exports.modules = {

/***/ 9842:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ ModalProvider),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const ModalContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({});
const useModal = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ModalContext);
const Modal = ()=>{
    const { show , ShowModal , CloseModal , data  } = useModal();
    const select = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: show ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "fixed top-0 bottom-0 left-0 right-0 bg-slate-100",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 w-full h-full relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "group absolute right-0 top-0 p-2 w-12 h-12 bg-slate-400 hover:bg-slate-600 transition-colors",
                        onClick: ()=>{
                            if (data.hasOwnProperty("onCancel")) {
                                data.onCancel();
                                return CloseModal();
                            }
                            return CloseModal();
                        },
                        title: "Close window",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            strokeWidth: 1.5,
                            stroke: "currentColor",
                            className: "group-hover:rotate-90 transition-transform",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                d: "M6 18L18 6M6 6l12 12"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "max-w-md rounded-lg mx-auto overflow-hidden shadow-lg",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                                className: `p-4 bg-blue-100 ${data.type === "info" ? "bg-blue-100" : data.type === "error" ? "bg-red-100" : "bg-yellow-100"}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-light text-xl font-sans",
                                    children: data.title || "Modal window"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "p-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: "font-serif text-gray-600 mb-4",
                                        children: [
                                            "We auto detected your current location as ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                className: "font-bold",
                                                children: "Minsk"
                                            }),
                                            " city. You can select another city from available cities list."
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                        ref: select,
                                        name: "cities",
                                        id: "selectCitiesList",
                                        className: "p-2 rounded-md w-full mb-4",
                                        children: data.AvailableCities.map((city, ind)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: city,
                                                children: city
                                            }, city + ind))
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: " bg-blue-300 rounded-lg px-4 py-2 hover:bg-blue-500 text-white transition-colors",
                                                title: "Ok, and close window",
                                                onClick: ()=>{
                                                    if (data.hasOwnProperty("onOk")) {
                                                        data.onOk(select.current?.value);
                                                        return CloseModal();
                                                    }
                                                    return CloseModal();
                                                },
                                                children: "Change location"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "rounded-lg px-4 py-2 text-gray-400 hover:text-black transition-colors",
                                                title: "Cancel and close window",
                                                onClick: ()=>{
                                                    if (data.hasOwnProperty("onCancel")) {
                                                        data.onCancel();
                                                        return CloseModal();
                                                    }
                                                    return CloseModal();
                                                },
                                                children: "Cancel"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        }) : null
    });
};
const ModalProvider = ({ children  })=>{
    const { 0: show , 1: setShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const ShowModal = (config)=>{
        setShow(true);
        setData(config);
    };
    const CloseModal = ()=>{
        setShow(false);
        setData(null);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ModalContext.Provider, {
        value: {
            show,
            setShow,
            data,
            ShowModal,
            CloseModal
        },
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Modal, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useModal);


/***/ })

};
;