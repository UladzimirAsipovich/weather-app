"use strict";
exports.id = 773;
exports.ids = [773];
exports.modules = {

/***/ 3875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


const MetaHead = (props)=>{
    const TITLE = props.title || `JustWeather. Just for you:)`;
    const DESCRIPTION = props.description || `Cool Weather App. View free weather forecast!`;
    const CURRENT_URL = `${"https://justweatherapp.com"}${props.currentUrl || ""}`;
    const IMAGE_URL = `${"https://justweatherapp.com"}${props.imageUrl || "/img/meta-logo.png"}`;
    const IMAGE_ALT = props.imageAlt || DESCRIPTION;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                charSet: "utf-8"
            }, "charSet"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                httpEquiv: "X-UA-Compatible",
                content: "ie=edge"
            }, "httpEquiv"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "robots",
                content: "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"
            }, "robots"),
            props.noFollow ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "robots",
                content: "noindex, nofollow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"
            }, "robots") : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "robots",
                content: "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"
            }, "robots"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "img/favicon/favicon.ico"
            }, "icon"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "apple-touch-icon",
                sizes: "180x180",
                href: `/img/favicon/apple-touch-icon.png`
            }, "apple-touch-icon"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                type: "image/png",
                sizes: "32x32",
                href: `/img/favicon/favicon-32x32.png`
            }, "32x32"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                type: "image/png",
                sizes: "16x16",
                href: `/img/favicon/favicon-16x16.png`
            }, "16x16"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "manifest",
                href: `/img/favicon/site.webmanifest`
            }, "manifest"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "viewport",
                content: "width=device-width, user-scalable=2, initial-scale=1, minimum-scale=1"
            }, "viewport"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "theme-color",
                content: "#434242"
            }, "theme-color"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "MobileOptimized",
                content: "320"
            }, "MobileOptimized"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "copyright",
                content: "Just Weather App"
            }, "copyright"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "yandex-verification",
                content: ""
            }, "yandex-verification"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "google-site-verification",
                content: ""
            }, "google-site-verification"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: TITLE
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                lang: "ru",
                itemProp: "description",
                content: DESCRIPTION
            }, "description"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                lang: "ru",
                content: props.keywords || DESCRIPTION
            }, "keywords"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "alternate",
                hrefLang: "ru",
                href: CURRENT_URL,
                title: "Russian"
            }, "alternate"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "canonical",
                href: CURRENT_URL
            }, "canonical"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:title",
                lang: "ru",
                content: TITLE
            }, "og:title"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:description",
                lang: "ru",
                content: DESCRIPTION
            }, "og:description"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:url",
                content: CURRENT_URL
            }, "og:url"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image",
                content: IMAGE_URL
            }, "og:image"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image:secure_url",
                content: IMAGE_URL
            }, "og:image:secure_url"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image:type",
                content: props.imageType || "image/png"
            }, "og:image:type"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image:width",
                content: props.imageWidth || "1000"
            }, "og:image:width"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image:height",
                content: props.imageHeight || "625"
            }, "og:image:height"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:image:alt",
                content: IMAGE_ALT
            }, "og:image:alt"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "business:contact_data:street_address",
                content: "пр. Дзержинского, 82"
            }, "business:contact_data:street_address"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "business:contact_data:locality",
                content: "Минск"
            }, "business:contact_data:locality"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "business:contact_data:region",
                content: "Минская область"
            }, "business:contact_data:region"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "business:contact_data:postal_code",
                content: "220089"
            }, "business:contact_data:postal_code"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "business:contact_data:country_name",
                content: "Belarus"
            }, "business:contact_data:country_name"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }, "twitter:card"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "twitter:description",
                lang: "ru",
                content: DESCRIPTION
            }, "twitter:description"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "twitter:title",
                lang: "ru",
                content: TITLE
            }, "twitter:title"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "twitter:image",
                content: IMAGE_URL
            }, "twitter:image"),
            props.children
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MetaHead);


/***/ }),

/***/ 8006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);


const OneDayTile = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "text-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: new Intl.DateTimeFormat("en-US", {
                        weekday: "long"
                    }).format(new Date(props.Day.dt_txt))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative w-24 mx-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: `http://openweathermap.org/img/wn/${props.Day.weather[0].icon}@2x.png`,
                    layout: "responsive",
                    width: 50,
                    height: 50,
                    alt: props.Day.weather[0].description
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                    children: [
                        props.Day.main.temp_min,
                        "\xbaC/",
                        props.Day.main.temp_max,
                        "\xbaC"
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (OneDayTile);


/***/ }),

/***/ 3701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ ONLY_ENG_LETTERS_REGEXP),
/* harmony export */   "i": () => (/* binding */ AvailableCities)
/* harmony export */ });
/**
 * Function, which return RegExp, included into yourself,  existence ONLY latins characters WITHOUT all other symbols.
 * @param from {number} NOT FLOAT a positive integer starting from zero
 * @param until {number} NOT FLOAT a positive integer starting from zero
 * @returns RegExp
 */ const ONLY_ENG_LETTERS_REGEXP = (from = 1, until = 50)=>{
    if (!Number.isInteger(from) || !Number.isFinite(from) || from < 0) throw new Error("@from parameter was expect is finite and positive number");
    if (!Number.isInteger(until) || !Number.isFinite(until) || until < 0) throw new Error("@until parameter was expect is finite and positive number");
    return new RegExp(`^[A-Za-z]{${from},${until}}$`, "i");
};
const AvailableCities = [
    "Minsk-BY",
    "Moscow-RU",
    "Bratislava-SK"
];


/***/ })

};
;